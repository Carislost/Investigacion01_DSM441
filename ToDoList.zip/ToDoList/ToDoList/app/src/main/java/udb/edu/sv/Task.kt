package udb.edu.sv

data class Task(val id: Int, val name: String, var isCompleted: Boolean)
